<?php
 $tekst ="Koriscenje HASH funkcija u PHP jeziku.";
echo crypt($tekst);
       echo"<br> Hash za string pomoću crypt funkcije";
?>