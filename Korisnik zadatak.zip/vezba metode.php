<?php
//$pt = new (naziv calsse) - objekti a public definisemo polja u klasi je javno prikazivanje bez greske i moze svako pristupiti.
//class su klase i umesto grupe array se koristi, a -> da ne bismo imali $
// private ne dozvoljava pristup $ jer su privatna 
//protected
//kada imamo i public i private onda je dostupno ali zavisi kome  a za pristup klase se koriste funkcije(function) koja se moze staviti u klasu(class) tada postaje metoda,
//Kada fuction ima prefiks private prijavice se greska
//Da bi se videla $X unutar funkcije moramo koristiti global $//
//echo $this->x; bice ispravno $pt1 umesto global
//sabiranje u klasi, public a i b i funkcija add() $ime klase new ime klase, a uz $this se koristi za sabiranje u echo se upisuje.
//staticki metod mul - public static function mul($a3 $b2 primer){} echo class ::mul();
//konstruktor klase kada se napraviu objekat automatski se startuje kada se instanciraklasa
//2 nacina konstrutora klase /prvi konstruktor (Public function __construct())/drugi imenom klase(public function )
//function __construct($a,$b){$math = new Math(20,10); $math->div(); primer pred kraj
//Za unistavanje objekta koristimo __destruct public function __destruct(){}
//public function render(){echo "x: {$this->x},y: {$this->y}";
//public function __construct($x,$y){$this->x = $x; $this->y = $y;}
//za gadjanje tacaka koristimo div
//shor import. 
//metod rende kopira iz klase
//magicni metod, je public function __tString(){}
//seter - public function setB{ $b;} i geter metode. 
//apstraktne klase se ne mogu instancirati.
class Korisnik 
{
private $id;
private $firstname;
private $lastname;
private $age;
public function __construct($id, $firstname, $lastname, $age)
{ $this->id = $id;
  $this->firstname = $firstname;
  $this->lastname = $lastname;
  $this->age = $age;
}
public function getimeiprezime()
{
return "$this->firstname $this->lastname";
}
public function Punoletan_je()
{
return $this->age >= 18;
}
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Klasa korisnik</title>
</head>

<body>
<?php
$instanca = new Korisnik(1, 'Miroslav', 'Kalinov', 18);
echo '<p>Korisnik: ' . $instanca->getimeiprezime() .'</p>';
echo '<p>Korisnik ' . ($instanca->Punoletan_je() ? 'je' : 'nije') . ' punoletan </p>';
?>
</body>

</html> 